from django.apps import AppConfig


class RsvpConfig(AppConfig):
    name = 'RSVP'
